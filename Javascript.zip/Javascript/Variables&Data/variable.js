var a = 45;
let b = "Saurav" ;
const author = "Saurav"
{
    let b = 'this'
    console.log(b)
}
console.log(a)