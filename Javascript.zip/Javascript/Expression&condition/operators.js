//Arithmetic operators
console.log("Operators in JS")
let a = 10;
let b = 4;
console.log("a + b =", a+b)
console.log("a - b =", a-b)
console.log("a / b =", a/b)
console.log("a ** b =", a**b)
console.log("a % b =", a%b)
console.log("++a =",  ++ a)

//Assignment Operator
 let assignment = 1;
 assignment += 5
 console.log("a is now =", a)

 //Comparison Operator
 let comp1= 6;
 let comp2 = 7;
 console.log("comp1 == comp2 is ", comp1 == comp2)

 //Logical operator
 let x = 5;
 let y = 6;
 console.log(x > y && x == 5)
