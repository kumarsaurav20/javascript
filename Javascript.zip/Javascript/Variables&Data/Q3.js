//Create a const object  in Javascript can you change it to hold a number later:
const a1 = {
    name: "Saurav",
    section: 1,
    isPrincipal: false
}
console.log(a1)