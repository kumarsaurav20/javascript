//Accusing value 
let number = [1, 2, 3, 4]
console.log(number[0])
console.log(number.length)

//changing the value 
number[3] = 5
console.log(number)

//array Methods
const num1 = [1, 7, 9]
console.log(num1.toString())

let n1 = [1, 3, 5, 7]
console.log(n1.join("-"))
console.log(n1.pop())

let n2 = [1, 2, 5]
b = n2.push(6)
console.log(n2,b)
//console.log(n2.push(9))
//delete n2[2]
//console.log(n2)
