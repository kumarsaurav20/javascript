//for loops--> a block of codes number of times :

/*
for ( st1 ; st2 ; st3){
    //code to be executed
}
*/

for (let i = 0; i < 30 ; i++){
    console.log(i)
}