let a = "Java"
let b = 345;
let c = true;
let d = BigInt("456") + BigInt("45")
let e = "Saurav"
let f = Symbol
let g = undefined
console.log(a, b, c, d, e, f, g)