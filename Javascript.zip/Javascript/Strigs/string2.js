let name = "Saurav Gupta"
console.log(name.length)
console.log(name.toUpperCase())
console.log(name.toLowerCase())
console.log(name.slice(2, 4))

//.Replace string
console.log(name.replace("Gupta", "Kumar"))
//adding string
console.log(name.concat(" is a software engineer"))

//For more strings google it and practice: