//Syntax of object from Js is same as syntax of Dictonary in Python
const item = {
    "Saurav": true,
    "Gupta": true,
    "Rohan": undefined,
    "Age": 23
}
console.log(item["Gupta"])