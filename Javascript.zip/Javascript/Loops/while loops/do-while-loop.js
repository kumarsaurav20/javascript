const prompt = require("prompt-sync")();
let n = prompt("Enter the vslue n :");
let i=0;
do {
    console.log(i)
    i++;
} while (i < n)