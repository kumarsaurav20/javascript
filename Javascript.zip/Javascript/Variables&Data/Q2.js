//Use type of operator to find the datatype of the string in last question 
let a = "Saurav"
let b = 20 ;
console.log(typeof (a + b))