//Document Oject Model=> document.body
//DOM represent the page as HTML content=> document.body.style.background="green" 

//Browser Object model=> ALert , confirm & Prompt are the part of BOM :


window.console.log(window)
console.log(document)
document.body.style.background="lavender"