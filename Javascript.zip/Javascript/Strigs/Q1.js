//Wap a program to convert a strig into lower case
let n1 = "saurav"
console.log(n1.toUpperCase())

//Extract the amount out of the string " Please give me Rs 1000"
let str1 = "Please give me Rs 1000"
console.log(str1.slice(15))

//Try to change the fourth character of a given string 
let str2 ="saurav"
str2[4] ="b"
console.log(str2) //str2 is not chsnged as string is immutable 
