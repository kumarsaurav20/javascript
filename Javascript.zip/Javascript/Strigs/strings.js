//Strings 
let name = "Saurav"
let n2 = 'Saurav'  //Strings can also be print in single quote

console.log(name.length)
console.log(n2)

//String Literals(Tempelate literals use backtick instead of quotes to define a string:) 
let boy1 = "Saurav"
let boy2 = "MJ"
let sentence = `${boy2} is friend of ${boy1}`
console.log(sentence)

//Escape sequence Characters
let name3 = 'Adam D \'Angelo'
let n4 = "Bana\"na"  
console.log(name3 , n4)

//double , single quote with back slash is used to escape the sequence:
