//Create a variable of type string and try to add a number to it:
let a = "Saurav"
let b = 20 ;
console.log(a + b)