//Write a function to find mean of 5 Numbers:
//Using Arrow function 
const mean = (a, b, c, d) => {
    return (a + b + c + d) / 4
}
console.log(mean(4, 5, 6, 7))