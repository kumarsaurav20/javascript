//Wap usig prompt fuction to take input of age as a value from the user
//and alert to tell them if he can drive
//(2) use conform to ask if the user wants to see the prompts again
const prompt = require("prompt-sync")()


let age = prompt("Enter Your age ")
age = Number.parseInt(age)

const canDrive = (age) => {
    age >= 18 ? true : false
}

if (canDrive(age)) {
    alert("Yes you ca Drive")
}
else {
    alert("You can not drive")

}
let color = prompt("Etnter the page background color")
document.body.style.background = color