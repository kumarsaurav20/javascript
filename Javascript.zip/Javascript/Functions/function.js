//Function is a block of code which is used to perform a task.
function Average(x, y) {
    console.log("Done")
    return (x + y) / 2
}  //This is function  which is used to perform a task 
let a = 2;
let b = 3;
let c = 4;

console.log("Average of a and b ", Average(a, b))
console.log("Average of b and c ", Average(b, c)) 

//No need to change every line of code just make function & change only once 