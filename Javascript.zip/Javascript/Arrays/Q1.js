//Create an array of numbers and take input from user to add numbers in array :
let arr = [1, 2, 3, 4]
const prompt = require("prompt-sync")()
let n = prompt("Enter the number to add :")
a = Number.parseInt(n)
arr.push(n)
console.log(arr)






